export const environment = {
    production:false,
    PAGE_SIZE: 6
}