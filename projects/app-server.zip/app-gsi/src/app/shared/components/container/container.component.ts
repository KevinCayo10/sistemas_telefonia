import { Component } from '@angular/core';

@Component({
  selector: 'gsi-container',
  templateUrl: './container.component.html',
  styleUrls: ['./container.component.css']
})
export class ContainerComponent {

}
