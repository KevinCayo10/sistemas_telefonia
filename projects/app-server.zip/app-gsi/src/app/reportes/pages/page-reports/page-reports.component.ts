import { Component } from '@angular/core';

@Component({
  selector: 'gsi-page-reports',
  templateUrl: './page-reports.component.html',
  styleUrls: ['./page-reports.component.css']
})
export class PageReportsComponent {

}
