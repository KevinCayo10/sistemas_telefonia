export interface Entidad {
  name: string;
  value: number;
}
