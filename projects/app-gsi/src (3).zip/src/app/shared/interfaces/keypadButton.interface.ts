export interface KeypadButton{
    icon:string;
    color:string;
    tooltip:string;
    accion:string;
}