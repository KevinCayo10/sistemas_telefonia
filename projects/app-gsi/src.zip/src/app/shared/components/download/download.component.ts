import { Component } from '@angular/core';

@Component({
  selector: 'gsi-download',
  templateUrl: './download.component.html',
  styleUrls: ['./download.component.css']
})
export class DownloadComponent {

}
