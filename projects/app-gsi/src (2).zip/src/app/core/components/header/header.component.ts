import { Component } from '@angular/core';

@Component({
  selector: 'gsi-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {

}
