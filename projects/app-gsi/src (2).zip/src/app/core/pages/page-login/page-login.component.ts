import { Component } from '@angular/core';

@Component({
  selector: 'gsi-page-login',
  templateUrl: './page-login.component.html',
  styleUrls: ['./page-login.component.css']
})
export class PageLoginComponent {

}
