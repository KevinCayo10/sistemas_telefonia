import { Component } from '@angular/core';

@Component({
  selector: 'gsi-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  ocultarPassword = true

}
