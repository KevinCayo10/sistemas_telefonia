import { Component } from '@angular/core';

@Component({
  selector: 'gsi-paginator',
  templateUrl: './paginator.component.html',
  styleUrls: ['./paginator.component.css']
})
export class PaginatorComponent {

}
