import { Component } from '@angular/core';

@Component({
  selector: 'gsi-keypad-button',
  templateUrl: './keypad-button.component.html',
  styleUrls: ['./keypad-button.component.css']
})
export class KeypadButtonComponent {

}
