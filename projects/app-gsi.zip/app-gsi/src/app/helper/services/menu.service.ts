import { Injectable } from '@angular/core';

export interface IMenu {
  title: string,
  url:string,
  icon:string
}

@Injectable({
  providedIn: 'root'
})
export class MenuService {
  private listaMenu:IMenu[] = [
    {title:'Clientes',url:'/clientes',icon:'/assets/icons/opcion.png'},
    {title:'Cobertura',url:'/cobertura',icon:'/assets/icons/opcion.png'},
    {title:'Planes',url:'/planes',icon:'/assets/icons/opcion.png'},
    {title:'Proveedores',url:'/proveedores',icon:'/assets/icons/opcion.png'},
    {title:'Soporte',url:'/soporte',icon:'/assets/icons/opcion.png'},
    {title:'Stock',url:'/stock',icon:'/assets/icons/opcion.png'},
    {title:'Técnicos',url:'/tecnicos',icon:'/assets/icons/opcion.png'},
    {title:'Usuarios',url:'/usuarios',icon:'/assets/icons/opcion.png'},
  ]
  constructor() { }

  getMenu():IMenu[]{
    return[...this.listaMenu]
  }

  getMenuByUrl(url:string):IMenu {
    return this.listaMenu.find(
      (menu) => menu.url.toLowerCase() === url.toLowerCase()
    ) as IMenu
  }
}
